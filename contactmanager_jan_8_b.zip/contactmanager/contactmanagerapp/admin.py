from django.contrib import admin
from .models import Contacttype,Contact
# Register your models here.
admin.site.register(Contacttype)
admin.site.register(Contact)

