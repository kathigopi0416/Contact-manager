from django.apps import AppConfig


class ContactmanagerappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'contactmanagerapp'
