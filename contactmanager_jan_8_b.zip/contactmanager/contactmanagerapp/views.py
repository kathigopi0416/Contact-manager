from django.forms.forms import Form
from django.shortcuts import redirect, render
from .forms import Contact_form
from .models import Contact
from django.contrib.auth.models import User
from django.contrib import messages

def home(request):
  return render(request,'home.html')

def register(request):
  if request.method == 'POST':
      first_name = request.POST['firstname']
      last_name = request.POST['lastname']
      # dob = request.POST['dob']
      username = request.POST['username']
      email = request.POST['email']
      password = request.POST['password']
      user = User.objects.create_user(first_name=first_name, last_name=last_name, 
                                                username=username, email=email,password=password)
      user.save()
      messages.success(request, "Registration successful." )
      return redirect('home')

  return render(request,'register.html')

def login(request):
  if request.method == 'POST':
      pass

  return render(request,'login.html')


def contact_list(request):
    content = {'contact_list' : Contact.objects.all()}
    return render(request, 'contact_list.html', content)

def contact_form(request, id=0):
    if request.method == "GET":
        if id == 0:
            form = Contact_form()
        else:
            contact = Contact.objects.get(pk=id)
            form = Contact_form(instance = contact)

        return render(request, 'contact_form.html', {'form':form})
    else:
        if id == 0:
            form = Contact_form(request.POST)
        else:
            contact = Contact.objects.get(pk=id)
            form = Contact_form(request.POST,instance=contact) 
              
        if form.is_valid():
            form.save()
            print("form saved successfully")
            return redirect('/contact/list')
        else:
            print("form IS NOT SAVED")
            content = {'error_list' : form.errors}

        return render(request,'error.html',content)
         
def contact_delete(request,id):
    contact = Contact.objects.get(pk=id)
    contact.delete()
    return redirect('/contact/list')