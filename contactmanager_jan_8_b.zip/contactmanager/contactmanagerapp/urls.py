from django.urls import path
from .import views 

urlpatterns = [
    path('home/',views.home,name='home'),
    path('login/',views.login,name='login_form'),
    path('register/',views.register,name='register_form'),

    path('',views.contact_form, name='contact_insert'),
    path('<int:id>/', views.contact_form, name='contact_update'),
    path('Delete/<int:id>/', views.contact_delete, name='contact_delete'),
    path('list/', views.contact_list, name='contact_list')
]