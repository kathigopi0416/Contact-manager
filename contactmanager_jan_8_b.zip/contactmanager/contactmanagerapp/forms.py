from types import MethodWrapperType
from django import forms
from django.forms import fields
from .models import Contact

class Contact_form(forms.ModelForm):

    class Meta:
        model = Contact
        fields = ('id','fullname','mobile','email','dob','Contacttype')
        labels = {
            'fullname':'Full Name',
            'dob':'DOB',
        }

    def __init__(self, *args, **kwargs):
        super(Contact_form,self).__init__(*args, **kwargs)
        self.fields['Contacttype'].empty_label='Select'
        self.fields['dob'].required = False
        self.fields['email'].required = False